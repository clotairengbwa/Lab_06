# Atelier 6 — Les chaînes de caractères

Cours BIN1000 — Principes de programmation.

Chaque exercice se trouve dans un fichier Python distinct (`exercice01.py` à `exercice12.py`).

Exécution : `python exercice01.py` (remplacer 01 par le numéro souhaité).

Chaque exercice a fait l’objet de son propre commit Git.

Pour publier ce dépôt sur GitHub, créez un dépôt vide nommé `Lab_06`, puis exécutez :

```bash
git remote add origin https://github.com/VOTRE_IDENTIFIANT/Lab_06.git
git branch -M main
git push -u origin main
```

Ne saisissez pas de véritable numéro de carte bancaire ou mot de passe pour tester les programmes.
