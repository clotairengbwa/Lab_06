numero = input("Entrez votre numéro de carte de crédit : ")
numero = numero.replace(" ", "").replace("-", "")
if not numero.isdigit():
    print("Erreur : le numéro doit contenir uniquement des chiffres.")
elif len(numero) < 16:
    print("Erreur : le numéro contient moins de 16 chiffres.")
elif len(numero) > 16:
    print("Erreur : le numéro contient plus de 16 chiffres.")
else:
    numero_masque = "*" * 12 + numero[-4:]
    print(f"Numéro masqué : {numero_masque}")
