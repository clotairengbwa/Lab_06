mot_de_passe = input("Entrez un mot de passe : ")
criteres = {
    "Au moins 8 caractères": len(mot_de_passe) >= 8,
    "Au moins une majuscule": any(c.isupper() for c in mot_de_passe),
    "Au moins une minuscule": any(c.islower() for c in mot_de_passe),
    "Au moins un chiffre": any(c.isdigit() for c in mot_de_passe),
    "Au moins un caractère spécial": any(not c.isalnum() and not c.isspace() for c in mot_de_passe),
}
for critere, respecte in criteres.items():
    print(f"{critere} : {'Respecté' if respecte else 'Non respecté'}")
if all(criteres.values()):
    print("Le mot de passe respecte tous les critères.")
else:
    print("Le mot de passe ne respecte pas tous les critères.")
