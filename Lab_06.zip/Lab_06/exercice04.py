mot = input("Entrez un mot : ")
if mot.lower() == mot.lower()[::-1]:
    print("Le mot est un palindrome.")
else:
    print("Le mot n'est pas un palindrome.")
