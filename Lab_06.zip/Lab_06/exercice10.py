numero = input("Entrez votre numéro de carte de crédit : ")
numero_masque = "*" * max(0, len(numero) - 4) + numero[-4:]
print(f"Numéro masqué : {numero_masque}")
