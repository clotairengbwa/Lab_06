chaine = input("Entrez un mot : ")
print(f"Résultat : {chaine[::-1]}")
