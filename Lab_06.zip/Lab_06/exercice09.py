phrase = input("Entrez une phrase : ")
mots = phrase.split()
if mots:
    print(f"Mot le plus long : {max(mots, key=len)}")
else:
    print("Aucun mot trouvé.")
