nom = input("Entrez un nom d'utilisateur : ")
if len(nom) >= 5 and nom.isalnum():
    print("Le nom d'utilisateur est valide.")
else:
    print("Le nom d'utilisateur n'est pas valide.")
