phrase = input("Entrez une phrase : ")
print(f"Nombre de mots : {len(phrase.split())}")
