mot = input("Entrez un mot : ")
voyelles = "aeiouy"
nombre = sum(1 for lettre in mot.lower() if lettre in voyelles)
print(f"Le mot contient {nombre} voyelles.")
